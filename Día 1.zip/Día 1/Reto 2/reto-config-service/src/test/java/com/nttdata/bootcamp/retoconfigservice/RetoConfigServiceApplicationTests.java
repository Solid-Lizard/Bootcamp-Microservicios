package com.nttdata.bootcamp.retoconfigservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetoConfigServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
