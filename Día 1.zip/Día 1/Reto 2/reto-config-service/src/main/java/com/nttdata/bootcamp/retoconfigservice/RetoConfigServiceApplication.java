package com.nttdata.bootcamp.retoconfigservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetoConfigServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetoConfigServiceApplication.class, args);
	}

}
